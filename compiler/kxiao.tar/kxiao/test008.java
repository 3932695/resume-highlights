

public class test008 {
    int x;
    void static main()
    {
        int x;
        int y;
        x = 0;
        while (x < 10) {
            System.out.println("Hello, world");
            x = x + 1;
        }
    }
    public static void main(String args) {
        main();
    }
}
